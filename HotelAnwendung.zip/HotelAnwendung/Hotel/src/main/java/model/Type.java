package model;

public enum Type {
    SINGLE, DOUBLE, TRIPLE, APARTMENT
}
